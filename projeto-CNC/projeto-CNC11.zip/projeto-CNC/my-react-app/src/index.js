import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import Agenda from "./Components/Pages/Agenda";

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <Agenda/>
  </StrictMode>,
)
